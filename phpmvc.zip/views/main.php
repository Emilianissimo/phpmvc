<h1 class="text-center my-3">Приложение задачник</h1>

<div class="row justify-content-center">
	<div class="col-md-4">

		<p>Данное приложение подготовлено в целях сдачи тестового задания.</p>
		<p>Была использована библиотека Eloquent ORM, вырзванная из Laravel.</p>
		<p>Все остальное самописное. Задачи вроде как полностью выполнены, так что прошу, тестируйте.</p>
		<p class="text-center">
			<a class="btn btn-success" href="/task">Задачи</a>
		</p>
	</div>
</div>