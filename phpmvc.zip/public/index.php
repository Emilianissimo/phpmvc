<?php

session_start();

ini_set('display_errors', 1);

include '../vendor/autoload.php';

require_once '../database/DB.php';

require_once '../config/bootstrap.php';
