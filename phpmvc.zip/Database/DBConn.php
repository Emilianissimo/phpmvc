<?php

namespace Database;

use Database\DBConn;

class DBConn{
	const DBDRIVER = 'mysql';
	const DBHOST = 'localhost';
	const DBNAME = 'phpmvc';
	const DBUSER = 'root';
	const DBPASS = '';
	// const PORT = '3306';
	// const CHAR = 'utf8mb4';
	const CHAR = 'utf8';
}
