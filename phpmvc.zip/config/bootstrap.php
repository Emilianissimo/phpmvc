<?php

namespace Config;

use Config\Core\View;
use Config\Core\Controller;
use Config\Core\Route;

Route::start();

